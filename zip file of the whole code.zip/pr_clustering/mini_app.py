import streamlit as st
st.title('Hello Streamlit 👋')
st.write('If you can see this, Streamlit is working.')